/**
 * 
 */
/**
 * @author Tereza
 *
 */
module projekt11 {
	requires java.sql;
	requires java.security.sasl;
}